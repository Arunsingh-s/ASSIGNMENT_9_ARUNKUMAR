
--create table for store data sequently form----
CREATE TABLE Employees (
   EmpID INT PRIMARY KEY,
   Name VARCHAR(50),
   DateOfBirth DATE,
   JoinDate DATE
 );
 ----------insert data created columns--------------
 INSERT INTO Employees (EmpID, Name, DateOfBirth, JoinDate) VALUES
(1, 'Alice Johnson', '1985-05-20', '2010-06-15'),
(2, 'Bob Smith', 	'1990-08-10', '2015-09-01'),
(3, 'Charlie Brown', '1988-03-25', '2012-11-12'),
(4, 'Diana Prince',  '1992-01-30', '2017-07-08'),
(5, 'Eve Adams', 	'1987-12-05', '2013-03-20');

--------------sql Query tasks-----------
 SELECT * FROM Employees;

--1-- Display the current date & time----------
 select current_timestamp ;

 --2---calculate Age-----------CALCULATE EACH EMPLOYEES AGE--
SELECT Name, FLOOR(DATEDIFF(DAYOFYEAR, DateOfBirth, GETDATE())/365.25) AS Age FROM Employees;

 ------------CALCULATE EXPERIENCE-----CALCULATE TOTAL YEAR OF SERVICE JOIN DATE---
 SELECT Name, FLOOR(DATEDIFF(DAYOFYEAR, JoinDate,GETDATE())/365.25) AS YearsExperience FROM Employees;

 ----------------------------EXTRACT DOB Components---------------------
 Select Name,YEAR(DateOfBirth) as BirthYear, MONTH(DateOfBirth) As BirthMonth,
 DAY(DateOfBirth) as BirthDay FROM Employees;

 -----------Born In August---------- list employees born in august---

 select Name FROM EMPLOYEES where MONTH(DateOfBirth) = 8;

 -------------Upcomming Birthdays------------------

SELECT Name
FROM Employees
WHERE 
FORMAT(DATEADD(YEAR, DATEDIFF(YEAR, DateOfBirth, GETDATE()), DateOfBirth), 'MM-dd')
BETWEEN FORMAT(GETDATE(), 'MM-dd')
AND FORMAT(DATEADD(DAY, 30, GETDATE()), 'MM-dd');
---------------

-------DATE_FORMAT, DATE_ADD , CURRENT_DATE, DOES NOT SUPPORT IN SQL FUCTION.----